package com.nocturne.client.render;

import com.nocturne.client.model.NocturnModel;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.world.level.block.Blocks;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.MultiBufferSource;
import com.nocturne.entity.NocturnEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import software.bernie.geckolib.renderer.GeoEntityRenderer;
import software.bernie.geckolib.renderer.layer.AutoGlowingGeoLayer;

public class NocturnRenderer extends GeoEntityRenderer<NocturnEntity> {
    public NocturnRenderer(EntityRendererProvider.Context context) {
        super(context, new NocturnModel());
        this.shadowRadius = 1.4F;
        this.addRenderLayer(new AutoGlowingGeoLayer<>(this));
    }

    @Override
    public void render(NocturnEntity entity, float entityYaw, float partialTick,
                       PoseStack poseStack, MultiBufferSource buffer, int packedLight) {
        // In the dormant/daytime phase render the real vanilla block model and texture,
        // not a hand-painted entity texture.
        if (entity.isDormant() || entity.getNightPower() < 0.08D) {
            poseStack.pushPose();
            poseStack.translate(-0.5D, 0.0D, -0.5D);
            Minecraft.getInstance().getBlockRenderer().renderSingleBlock(
                Blocks.COBBLESTONE.defaultBlockState(), poseStack, buffer,
                packedLight, OverlayTexture.NO_OVERLAY);
            poseStack.popPose();
            return;
        }
        super.render(entity, entityYaw, partialTick, poseStack, buffer, packedLight);
    }
}
